

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto">
    <div class="bg-white shadow rounded-lg p-6">
        <h1 class="text-2xl font-semibold">Espace Caisse</h1>
        <p class="text-sm text-gray-600 mt-2">Bienvenue dans l'espace caisse. Utilisez le menu pour effectuer des ventes.</p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.accueil', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\nadège.djossou\Documents\stock\resources\views/caisse/dashboard.blade.php ENDPATH**/ ?>