@extends('layouts.accueil')

@section('content')

@endsection
